# ING_CIVIL_PPE_Detection_YOLO11 > 2026-11-17 9:27am
https://universe.roboflow.com/hilders-workspace/ing_civil_ppe_detection_yolo11

Provided by a Roboflow user
License: CC BY 4.0

